//
//  BNCXcode7Support.m
//  Branch-TestBed
//
//  Created by Edward on 10/26/16.
//  Copyright © 2016 Branch Metrics. All rights reserved.
//


#import "BNCXcode7Support.h"


#if defined(__IPHONE_OS_VERSION_MAX_ALLOWED) && __IPHONE_OS_VERSION_MAX_ALLOWED < 100000
//  Usually nothing goes here.
#endif

