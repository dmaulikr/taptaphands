//
//  BNCError.m
//  Branch-SDK
//
//  Created by Qinwei Gong on 11/17/14.
//  Copyright (c) 2014 Branch Metrics. All rights reserved.
//


#import "BNCError.h"


NSString * const BNCErrorDomain = @"io.branch";

@implementation BNCError

@end
